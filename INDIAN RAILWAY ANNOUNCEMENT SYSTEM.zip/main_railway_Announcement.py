# pip install pyaudio
# pip install pydub
# pip install pandas
# pip install gTTS

import os
import pandas as pd
from pydub import AudioSegment  #“Pydub lets you do stuff to audio in a way that isn’t stupid.”pydum needs ffmpeg
from gtts import gTTS   #Google Text-to-Speech), a Python library and CLI tool to interface with Google Translate's text-to-speech API.


def text_to_Speech(text,filename):
    my_Text=str(text)  #because it could be an integer also thats why converting it to string
    language = 'hi'
    myobj = gTTS(text=my_Text,lang=language,slow=True) #slow =TRue because i want it to spell the words slowly so that we can easily understand
    myobj.save(filename)
def Merge_the_Audio(audios):
    #THIS FUNCTION RETURNS PYDUB AUDIO SEGMENT

    combined_mp3=AudioSegment.empty() #empty audio

    for audio in audios:
        combined_mp3 = combined_mp3+AudioSegment.from_mp3(audio) # stiching all the empty files
    return combined_mp3
def Generate_skeleton():
    #in pydub everything is in milisecond so we have to covert everything to milisecond
    audio = AudioSegment.from_mp3('railway.mp3 ')
    # 1 Generating "kripyaa dhyan dijiee" audio in the folder from the clip we have
    start =88000
    finish =90200
    audio_processed = audio[start:finish]
    audio_processed.export("1_hindi.mp3",format="mp3")
     # 2 city from


    #" 3 ......se chal kr"
    start = 91000
    finish = 92200
    audio_processed = audio[start:finish]
    audio_processed.export("3_hindi.mp3", format="mp3")

    # 4 is via-city

    # 5 - Generate ke raaste
    start = 94000
    finish = 95000
    audioProcessed = audio[start:finish]
    audioProcessed.export("5_hindi.mp3", format="mp3")

    # 6 is to-city

    # 7 - Generate ko jaane wali gaadi sakhya
    start = 96000
    finish = 98900
    audioProcessed = audio[start:finish]
    audioProcessed.export("7_hindi.mp3", format="mp3")

    # 8 Generating is train no and name

    # 9 - Generate ----kuch hi samay mei platform sankhya
    start = 105500
    finish = 108200
    audioProcessed = audio[start:finish]
    audioProcessed.export("9_hindi.mp3", format="mp3")

    # 10 is platform number

    # 11 - Generate ----par aa rahi hai
    start = 109000
    finish = 112250
    audioProcessed = audio[start:finish]
    audioProcessed.export("11_hindi.mp3", format="mp3")

def Generate_Announcement(filename):
    df = pd.read_excel(filename)
    print(df)

    for index,item in df.iterrows():
        # 2 generate the city
        text_to_Speech(item['from'],'2_hindi.mp3')
        # 4 - Generate via-city
        text_to_Speech(item['via'], '4_hindi.mp3')

        # 6 - Generate to-city
        text_to_Speech(item['to'], '6_hindi.mp3')

        # 8 - Generate train no and name
        text_to_Speech(str(item['train_no']) + " " + str(item['train_name']),'8_hindi.mp3')

        # 10 - Generate platform number
        text_to_Speech(item['platform'], '10_hindi.mp3')

        audios = [f"{i}_hindi.mp3" for i in range(1,12)]

        announcement= Merge_the_Audio(audios)
        announcement.export(f"announcement_{item['train_no']}_{index+1}.mp3",format="mp3")

if __name__ == '__main__':
    print("Generating the skeleton")
    Generate_skeleton()
    print("Now generating Announcement......")
    Generate_Announcement("announcement_sheet.xlsx")